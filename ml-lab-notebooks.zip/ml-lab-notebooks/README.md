# ML Lab Notebooks

Jupyter/Colab notebooks from my lab work (NumPy, Decision Trees, KNN).

## Contents

| Notebook | Topic |
|---|---|
| `notebooks/01_numpy_basics.ipynb` | NumPy basics: arrays, shape, size, dtype, zeros, ones, arange, linspace |
| `notebooks/02_untitled1.ipynb` | Practice notebook |
| `notebooks/03_numpy_array_to_image_analysis.ipynb` | NumPy hands-on: array to image analysis |
| `notebooks/04_decision_trees.ipynb` | Decision Trees |
| `notebooks/05_knn_iris.ipynb` | Experiment 4: KNN on the Iris dataset |

## Run

Open any notebook in [Google Colab](https://colab.research.google.com/) or locally:

```bash
pip install numpy matplotlib scikit-learn pandas jupyter
jupyter notebook
```

## Author

AP24110010798
